
# Stores fonts
class Fonts:
    Courier = "assets/fonts/courier.ttf"