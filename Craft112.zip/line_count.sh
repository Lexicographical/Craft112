find . -name '*.py' | xargs wc -l
